export const environment = {
  production: false,
  name: 'dev',
};
